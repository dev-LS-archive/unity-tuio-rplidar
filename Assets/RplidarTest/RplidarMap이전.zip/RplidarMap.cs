﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Threading;

[RequireComponent(typeof(MeshFilter))]
public class RplidarMap : MonoBehaviour {

    public bool m_onscan = false;

    private LidarData[] m_data;
    public string COM = "COM3";

    public Mesh m_mesh;

    public int startNum;

    public List<Vector3> m_vert;
    public List<Vector3> mm_vert;
    public List<Vector3> start_vert;
    private List<int> m_ind;
    private List<int> m_ind_zero;

    public float deltime;
    public float currentDeltime;

    private MeshFilter m_meshfilter;

    private Thread m_thread;
    private bool m_datachanged = false;
	void Start () {
        deltime = 1;
        currentDeltime = 1;
        m_meshfilter = GetComponent<MeshFilter>();

        m_data = new LidarData[720];

        m_ind = new List<int>();
        m_ind_zero = new List<int>();

        m_vert = new List<Vector3>();
        mm_vert = new List<Vector3>();

        start_vert = new List<Vector3>();

        for (int i = 0; i < 720; i++)
        {
            m_ind.Add(i);
            m_ind_zero.Add(10);
            mm_vert.Add(Vector3.zero);
            start_vert.Add(Vector3.zero);
            Debug.Log("초기화");
        }
        m_mesh = new Mesh();
        m_mesh.MarkDynamic();

        RplidarBinding.OnConnect(COM);
        RplidarBinding.StartMotor();
        m_onscan = RplidarBinding.StartScan();


        if (m_onscan)
        {
            m_thread = new Thread(GenMesh);
            m_thread.Start();
        }

        //처음위치추가

       
    }

   
    void OnDestroy()
    {
        m_thread.Abort();

        RplidarBinding.EndScan();
        RplidarBinding.EndMotor();
        RplidarBinding.OnDisconnect();
        RplidarBinding.ReleaseDrive();

        m_onscan = false;
    }

    void Update()
    {
 
        if (m_datachanged)
        {
          
           
            if(startNum < 100)
            {

                ////////////////////////////////////////////////////////////////////////////초기셋

                for (int i = 0; i < 720; i++)
                {
                    if ((Quaternion.Euler(0, 0, m_data[i].theta) * Vector3.right * m_data[i].distant * 0.01f) != Vector3.zero)
                    {
                        start_vert[i] = (Quaternion.Euler(0, 0, m_data[i].theta) * Vector3.right * m_data[i].distant * 0.01f);
                    }
                }


                m_vert.Clear();

                for (int i = 0; i < 720; i++)
                {
                    m_vert.Add(Quaternion.Euler(0, 0, m_data[i].theta) * Vector3.right * m_data[i].distant * 0.01f);

                    if (mm_vert[i] != m_vert[i] && m_vert[i] != Vector3.zero)
                    {
                        if (Math.Abs(start_vert[i].x - m_vert[i].x) < 1)
                        {
                           // Debug.Log("패스" + Math.Abs(start_vert[i].x - m_vert[i].x));
                        }

                        if (i > 0)
                        {
                            if (Vector3.Distance(m_vert[i], m_vert[i - 1]) > 0.5f)
                            {
                               
                              //  Debug.Log("터치" + Vector3.Distance(m_vert[i], m_vert[i - 1]));

                                if ((int)Vector3.Distance(m_vert[i], m_vert[i - 1]) != 0)
                                m_ind_zero[i] = (int)Vector3.Distance(m_vert[i], m_vert[i - 1]);
                            }
                        }
                    }
                }

                mm_vert.Clear();

                for (int i = 0; i < 720; i++)
                {
                    mm_vert.Add(Quaternion.Euler(0, 0, m_data[i].theta) * Vector3.right * m_data[i].distant * 0.01f);
                }

                m_mesh.SetVertices(m_vert);
                m_mesh.SetIndices(m_ind.ToArray(), MeshTopology.Points, 0);

                m_mesh.UploadMeshData(false);
                m_meshfilter.mesh = m_mesh;

                m_datachanged = false;

                ////////////////////////////////////////////////////////////////////////////////////////초기셋끝


                startNum++;
            }
            else
            {
                m_vert.Clear();

                for (int i = 0; i < 720; i++)
                {
                    m_vert.Add(Quaternion.Euler(0, 0, m_data[i].theta) * Vector3.right * m_data[i].distant * 0.01f);

                    if (mm_vert[i] != m_vert[i] && m_vert[i] != Vector3.zero)
                    {
                        if (Math.Abs(start_vert[i].x - m_vert[i].x) < 1)
                        {
                          //  Debug.Log("패스" + Math.Abs(start_vert[i].x - m_vert[i].x));
                            continue;
                           
                        }

                        if (i > 0)
                        {                        
                            if (Vector3.Distance(m_vert[i], m_vert[i - 1]) > 0.5f)
                            {
                              
                                if(m_ind_zero[i] != Vector3.Distance(m_vert[i], m_vert[i - 1]))
                                {
                                    Debug.Log("터치" + Vector3.Distance(m_vert[i], m_vert[i - 1]));
                                }
                            }
                        }
                    }
                }

                mm_vert.Clear();

                for (int i = 0; i < 720; i++)
                {
                    mm_vert.Add(Quaternion.Euler(0, 0, m_data[i].theta) * Vector3.right * m_data[i].distant * 0.01f);
                }

                m_mesh.SetVertices(m_vert);
                m_mesh.SetIndices(m_ind.ToArray(), MeshTopology.Points, 0);

                m_mesh.UploadMeshData(false);
                m_meshfilter.mesh = m_mesh;

                m_datachanged = false;
            }

           
        }
    }

    void GenMesh()
    {
        while (true)
        {
            int datacount = RplidarBinding.GetData(ref m_data);
            if (datacount == 0)
            {
                Thread.Sleep(20);
            }
            else
            {
                m_datachanged = true;
            }
        }
    }

}
